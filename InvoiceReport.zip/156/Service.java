//parkingpass and refreshments
public abstract class Service extends Product{

	public Service(String productCode, String productType) {
		super(productCode, productType);
	}
	//tax rate calculation
}
