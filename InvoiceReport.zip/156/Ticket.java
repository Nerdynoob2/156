//movie ticket and season pass
public abstract class Ticket extends Product{

	public Ticket(String productCode, String productType) {
		super(productCode, productType);
	}
	//tax rate calculation
}
