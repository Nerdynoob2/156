
public class MyIterator<T> implements java.util.Iterator<T> {
	
	private int currentPlace;

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T next() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
